#define RFID_RX_SIZE 512
#define RFID_CARD_EMPTY "00000000000000"
#define RFID_CARD_ERROR "EEEEEEEEEEEEEE"
#define RFID_READ_RESPONSE_LEN 13
#define RFID_WRITE_RESPONSE_LEN 8
#define RFID_FIRST_BYTE_TIMEOUT_MS 100
#define RFID_INTER_BYTE_TIMEOUT_MS 20
static byte RFID_RX[RFID_RX_SIZE];

byte rFID_Enable = 0;
byte rFID_Enable_buf = -1;
bool RFID_Init = true;
String CardID_temp = "";
int RFID_Error = 0;

void Clear_RFID_485_RX()
{
    unsigned long startTime = millis();
    while(mySerial_485.available() && (millis() - startTime) < 5)
    {
        mySerial_485.read();
    }
}

String RFID_ByteToHex(byte value)
{
    String hex = String(value, HEX);
    if(hex.length() < 2) hex = "0" + hex;
    hex.toUpperCase();
    return hex;
}

void RFID_DebugPrintBytes(const char* title, const byte* data, int len)
{
    if(!flag_udp_232back) return;

    mySerial.print(title);
    mySerial.print(" [");
    mySerial.print(len);
    mySerial.print("] ");
    for(int i = 0 ; i < len ; i++)
    {
        if(data[i] < 0x10) mySerial.print("0");
        mySerial.print(data[i], HEX);
        if(i < len - 1) mySerial.print(" ");
    }
    mySerial.println();
}

void RFID_DebugError(byte station, byte function, const char* reason, const byte* rx, int len)
{
    if(!flag_udp_232back) return;

    mySerial.print("RFID ERR station=");
    mySerial.print(station);
    mySerial.print(" func=0x");
    if(function < 0x10) mySerial.print("0");
    mySerial.print(function, HEX);
    mySerial.print(" reason=");
    mySerial.println(reason);
    if(len > 0)
    {
        RFID_DebugPrintBytes("RFID RX", rx, len);
    }
}

bool RFID_ReadResponse(byte station, byte function, byte* rx, int expectedLen, int firstByteTimeoutMs, int interByteTimeoutMs)
{
    int rxLen = 0;
    bool errorPrinted = false;
    unsigned long startTime = millis();
    unsigned long lastByteTime = startTime;

    while((millis() - startTime) < (unsigned long)firstByteTimeoutMs)
    {
        while(mySerial_485.available())
        {
            byte value = mySerial_485.read();

            if(rxLen == 0 && value != station)
            {
                continue;
            }

            if(rxLen >= expectedLen)
            {
                RFID_DebugError(station, function, "RX_OVERFLOW", rx, rxLen);
                errorPrinted = true;
                rxLen = 0;
                continue;
            }

            rx[rxLen] = value;
            rxLen++;
            lastByteTime = millis();

            if(rxLen == 2 && rx[1] != function)
            {
                RFID_DebugError(station, function, "FUNCTION_MISMATCH", rx, rxLen);
                errorPrinted = true;
                rxLen = 0;
                continue;
            }

            if(function == 0x03 && rxLen == 3 && rx[2] != 0x08)
            {
                RFID_DebugError(station, function, "BYTE_COUNT_MISMATCH", rx, rxLen);
                errorPrinted = true;
                rxLen = 0;
                continue;
            }

            if(rxLen == expectedLen)
            {
                if(Get_CRC16(rx , expectedLen) == 0)
                {
                    RFID_DebugPrintBytes("RFID RX OK", rx, rxLen);
                    return true;
                }
                RFID_DebugError(station, function, "CRC_ERROR", rx, rxLen);
                errorPrinted = true;
                return false;
            }
        }

        if(rxLen > 0 && (millis() - lastByteTime) >= (unsigned long)interByteTimeoutMs)
        {
            RFID_DebugError(station, function, "INTER_BYTE_TIMEOUT", rx, rxLen);
            errorPrinted = true;
            break;
        }

        delay(0);
    }

    if(!errorPrinted)
    {
        RFID_DebugError(station, function, "FIRST_BYTE_TIMEOUT", rx, rxLen);
    }
    return false;
}

bool RFID_ModbusTransaction(byte station, const byte* tx, int txLen, byte* rx, int expectedLen, int firstByteTimeoutMs, int interByteTimeoutMs)
{
    byte function = tx[1];

    Clear_RFID_485_RX();
    RFID_DebugPrintBytes("RFID TX", tx, txLen);
    Set_RS485_Tx_Enable();
    mySerial_485.write(tx , txLen);
    mySerial_485.flush();
    Set_RS485_Rx_Enable();

    return RFID_ReadResponse(station, function, rx, expectedLen, firstByteTimeoutMs, interByteTimeoutMs);
}

void sub_RFID_program()
{
    rFID_Enable = Get_RFID_Enable();
    if(rFID_Enable_buf != rFID_Enable)
    {       
       if(flag_udp_232back)printf("RFID_Enable : %d\n" , rFID_Enable);
       rFID_Enable_buf = rFID_Enable;
       flag_JsonSend = true;
    }
    if(RFID_Init) 
    {
      wiFiConfig.Get_RFID_Enable();
      
    }
    for(int i = 0 ; i < 5 ; i++)
    {
      if(RFID_Init)
      {
        if(((wiFiConfig.rFID_Enable >> i) % 2) == 1)Set_Beep(i + 1);     
        CardID[i] = RFID_CARD_EMPTY;
        CardID_buf[i] = RFID_CARD_EMPTY;
      }
      else
      {
        if(((wiFiConfig.rFID_Enable >> i) % 2) == 1)
        {
            CardID_temp = Get_7CardID(i + 1);
            CardID[i] = CardID_temp;
            
        }
        else
        {
           CardID[i] = RFID_CARD_EMPTY;
           CardID_buf[i] = RFID_CARD_EMPTY;
        } 
      }
      if(RFID_Error >= 20)
      {
//         ESP.restart();       
      }
    }
    RFID_Init = false;
    
}
void Set_RFID_Enable(byte index , bool value)
{
    byte temp = wiFiConfig.Get_RFID_Enable();
    
    if(value)
    {
      temp = temp |(1 << index);
    }    
    else
    {
      temp = temp & ~(1 << index);
    }
    wiFiConfig.Set_RFID_Enable(temp);
}
byte Get_RFID_Enable()
{
    return wiFiConfig.rFID_Enable;
}
String Get_7CardID(byte station)
{
   int retry = 0;
   byte tx[8];
   tx[0] = station;
   tx[1] = 0x03;
   tx[2] = 0x00;
   tx[3] = 0x00;
   tx[4] = 0x00;
   tx[5] = 0x04;
   uint16_t CRC = Get_CRC16(tx , 6);
   tx[6] = CRC;
   tx[7] = (CRC >> 8);

   for(retry = 0 ; retry < 3 ; retry++)
   {
     for (int i = 0 ; i < RFID_RX_SIZE ; i++)
     {
         RFID_RX[i] = 0;         
     }

     if(RFID_ModbusTransaction(station, tx, 8, RFID_RX, RFID_READ_RESPONSE_LEN, RFID_FIRST_BYTE_TIMEOUT_MS, RFID_INTER_BYTE_TIMEOUT_MS))
     {
        String HEX_0 = RFID_ByteToHex(RFID_RX[3]);
        String HEX_1 = RFID_ByteToHex(RFID_RX[4]);
        String HEX_2 = RFID_ByteToHex(RFID_RX[5]);
        String HEX_3 = RFID_ByteToHex(RFID_RX[6]);
        String HEX_4 = RFID_ByteToHex(RFID_RX[7]);
        String HEX_5 = RFID_ByteToHex(RFID_RX[8]);
        String HEX_6 = RFID_ByteToHex(RFID_RX[9]);
        RFID_Error = 0;
        String CardID = HEX_0 + HEX_1 + HEX_2 + HEX_3 + HEX_4 + HEX_5 + HEX_6;
        if(flag_udp_232back)
        {
           printf("station : %d , ID : " ,station);
           mySerial.println(CardID);
        }
        return HEX_0 + HEX_1 + HEX_2 + HEX_3 + HEX_4 + HEX_5 + HEX_6;
     }
     else
     {
        if(flag_udp_232back)printf("station : %d , RFID read retry : %d\n" ,station ,retry + 1);
     }
     delay(1);
   }
   RFID_Error++;
   return RFID_CARD_ERROR;
}
bool Set_Beep(byte station)
{
   int retry = 0;
   byte tx[8];
   tx[0] = station;
   tx[1] = 0x06;
   tx[2] = 0x00;
   tx[3] = 0x04;
   tx[4] = 0x00;
   tx[5] = 0x02;   
   uint16_t CRC = Get_CRC16(tx , 6);
   tx[6] = CRC;
   tx[7] = (CRC >> 8);

   for(retry = 0 ; retry < 2 ; retry++)
   {
     for (int i = 0 ; i < RFID_RX_SIZE ; i++)
     {
         RFID_RX[i] = 0;         
     }

     if(RFID_ModbusTransaction(station, tx, 8, RFID_RX, RFID_WRITE_RESPONSE_LEN, 200, RFID_INTER_BYTE_TIMEOUT_MS))
     {
        bool echoOk = true;
        for(int i = 0 ; i < RFID_WRITE_RESPONSE_LEN ; i++)
        {
            if(tx[i] != RFID_RX[i])
            {
                echoOk = false;
                break;
            }
        }
        if(echoOk)
        {
            if(flag_udp_232back)printf("RFID Set Beep sucess , station : %d \n",station);
            return true;
        }
        RFID_DebugError(station, tx[1], "WRITE_ECHO_MISMATCH", RFID_RX, RFID_WRITE_RESPONSE_LEN);
     }
     else
     {        
        if(flag_udp_232back)printf("RFID Set Beep retry , station : %d , retry : %d \n",station, retry + 1);
     }
   }
   if(flag_udp_232back)printf("RFID Set Beep failed , station : %d \n",station);
   return false;    
}
void Set_RS485_Rx_Enable()
{
    digitalWrite(PIN_485_Tx_Eanble, LOW);
    delayMicroseconds(100);
}
void Set_RS485_Tx_Enable()
{
    digitalWrite(PIN_485_Tx_Eanble, HIGH);
    delayMicroseconds(100);
}
